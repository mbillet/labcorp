﻿namespace LabCorp.DTO
{
    public class EmployeePost
    {
        public long ID { get; set; } = 0;
        public int DaysWorked { get; set; } = 0;
        public float VacationDaysAvailable { get; set; } = 0.0f;
        public float VacationDaysTaken { get; set; } = 0.0f;
        public float VacationDaysRequested { get; set; } = 0.0f;
    }
}
