﻿using LabCorp.Model;
using LabCorp.DTO;
using Microsoft.AspNetCore.Mvc;

namespace LabCorp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly ILogger<EmployeeController> _logger;
        private static Employee[] employees;
        static EmployeeController()
        {
            employees = new Employee[30];
            for (int i = 0; i < employees.Length; i++)
            {
                if (i < 10)
                    employees[i] = new HourlyEmployee {Name = "Hourly" + (i % 10 + 1)};
                else
                    if (i < 20)
                    employees[i] = new SalariedEmployee { Name = "Salaried" + (i % 10 + 1) };
                else
                    employees[i] = new Manager { Name = "Manager" + (i % 10 + 1) };
                employees[i].ID = i + 1;
            }
        }
        public EmployeeController(ILogger<EmployeeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return EmployeeController.employees;
        }

        [Route("[action]")]
        [HttpPost("Work")]
        public ActionResult<EmployeePost> Work([FromBody] EmployeePost ep)
        {
            try
            {
                employees[ep.ID - 1].Work(ep.DaysWorked);
                ep.DaysWorked = employees[ep.ID - 1].DaysWorked;
                ep.VacationDaysAvailable = employees[ep.ID - 1].VacationDaysAvailable;
                return Ok(ep);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("[action]")]
        [HttpPost("TakeVacation")]
        public ActionResult<EmployeePost> TakeVacation([FromBody] EmployeePost ep)
        {
            try
            {
                employees[ep.ID - 1].TakeVacation(ep.VacationDaysRequested);
                ep.VacationDaysTaken = employees[ep.ID - 1].VacationDaysTaken;
                ep.VacationDaysAvailable = employees[ep.ID - 1].VacationDaysAvailable;
                return Ok(ep);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}