import { HttpClient } from '@angular/common/http';
import { Component, Inject, Input, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { CellClickedEvent, ColDef, GridReadyEvent, IRowNode, RowDataUpdatedEvent, RowSelectedEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  public title!: string;
  // Each Column Definition results in one Column.
  public columnDefs: ColDef[] = [
    { field: 'id' },
    { field: 'name' },
    {
      field: 'employeeType',
      valueFormatter: params => {
        switch (params.value) {
          case 0:
            return 'Hourly';
          case 1:
            return 'Salaried';
          case 2:
            return 'Manager';
          default:
            break;
        }
        return params.value;
      }
    },
    {
      field: 'daysWorked',
      colId: 'daysWorked',
    },
    {
      field: 'vacationDaysAvailable',
      colId: 'vacationDaysAvailable',
      valueFormatter: params => {
        return params.value.toFixed(2);
      }
    },
    {
      field: 'vacationDaysTaken',
      colId: 'vacationDaysTaken',
      valueFormatter: params => {
        return params.value.toFixed(2);
      }
    },
    { field: 'maxVacationDays' },
  ];

  // DefaultColDef sets props common to all Columns
  public defaultColDef: ColDef = {
    sortable: true,
    filter: true,
  };

  // Data that gets displayed in the grid
  public rowData$!: Observable<any[]>;
  public baseUrl: string;
  @Input() public daysWorked!: number | null;
  @Input() public vacationDaysRequested!: number | null;
  isSelected: boolean = false;
  id: number | undefined | null;
  public rowNode!: IRowNode<any>;

  // For accessing the Grid's API
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;

  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  // Example load data from sever
  onGridReady(params: GridReadyEvent) {
    try {
      this.rowData$ = this.http.get<any[]>(this.baseUrl + 'employee')
    }
    catch (e) { console.log("error in onGridReady") }
  }

  onRowSelected(e: RowSelectedEvent): void {
    if (e.node.isSelected()) {
      this.isSelected = true;
      this.id = e.data.id;
      this.rowNode = e.node;
    }
  }

  // Example using Grid's API
  clearSelection(): void {
    this.agGrid.api.deselectAll();
    this.isSelected = false;
    this.id = null;
  }

  onWorkButtonClicked(): void {
    if (!this.isSelected) {
      alert("select row")
      return
    }
    console.log(this.daysWorked)
    const headers = { 'Content-Type': 'application/json', 'Accept': '*/*' };
    const body = { 'ID': this.id, 'DaysWorked': this.daysWorked };
    try {
      this.http.post<any>(this.baseUrl + 'employee/Work', body, { 'headers': headers }).subscribe(
        (response) => {
          console.log('response received')
          //this.rowData$ = this.http.get<any[]>(this.baseUrl + 'employee')
          this.rowNode.setDataValue('daysWorked', response["daysWorked"]);
          this.rowNode.setDataValue('vacationDaysAvailable', response["vacationDaysAvailable"]);
          this.daysWorked = null;
        },
        (error) => {
          console.error('error caught in component')
          console.log(error);
          alert(error.error);
        });
    }
    catch (error) { console.log(error); }
  }

  onVacationButtonClicked(): void {
    if (!this.isSelected) {
      alert("select row")
      return
    }
    console.log(this.vacationDaysRequested)
    const headers = { 'Content-Type': 'application/json', 'Accept': '*/*' };
    const body = { 'ID': this.id, 'VacationDaysRequested': this.vacationDaysRequested };
    try {
      this.http.post<any>(this.baseUrl + 'employee/TakeVacation', body, { 'headers': headers }).subscribe(
        (response) => {
          console.log('response received')
          //this.rowData$ = this.http.get<any[]>(this.baseUrl + 'employee')
          this.rowNode.setDataValue('vacationDaysTaken', response["vacationDaysTaken"]);
          this.rowNode.setDataValue('vacationDaysAvailable', response["vacationDaysAvailable"]);
          this.vacationDaysRequested = null;
        },
        (error) => {
          console.error('error caught in component')
          console.log(error);
          alert(error.error);
        });
    }
    catch (error) { console.log(error); }
  }
}

