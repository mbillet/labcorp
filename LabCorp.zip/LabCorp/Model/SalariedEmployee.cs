﻿namespace LabCorp.Model
{
    public class SalariedEmployee : Employee
    {
        public SalariedEmployee()
        {
            this.EmployeeType = EmployeeType.Salaried;
        }
        public override int MaxVacationDays
        {
            get
            {
                return 15;
            }
        }
    }
}
