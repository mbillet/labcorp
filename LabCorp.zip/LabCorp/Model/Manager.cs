﻿namespace LabCorp.Model
{
    public class Manager : Employee
    {
        public Manager()
        {
            this.EmployeeType = EmployeeType.Manager;
        }
        public override int MaxVacationDays
        {
            get
            {
                return 30;
            }
        }
    }
}
