namespace LabCorp.Model
{
    public abstract class Employee
    {
        public long ID { get; set; } = 0;
        public EmployeeType EmployeeType { get; set; }
        public string? Name { get; set; }

        public int DaysWorked { get; private set; } = 0;

        public float VacationDaysAvailable { get; private set; }
        public float VacationDaysTaken { get; private set; }
        public abstract int MaxVacationDays { get; }
        public void Work(int days)
        {
            if (DaysWorked + days > MaxWorkDays)
                throw new Exception("Work Days cannot exceed 260");

            DaysWorked += days;
            VacationDaysAvailable = ((float)DaysWorked / MaxWorkDays * MaxVacationDays) - VacationDaysTaken;
        }
        public void TakeVacation(float days)
        {
            if (Math.Round(days,2) > Math.Round(VacationDaysAvailable,2))
                throw new Exception("Only " + Math.Round(VacationDaysAvailable,2) +" Vacation Days are available ");

            VacationDaysAvailable -= days;
            if (VacationDaysAvailable < 0)
                VacationDaysAvailable = 0;
            VacationDaysTaken += days;
        }
        const int MaxWorkDays = 260;
    }

    public enum EmployeeType
    {
        Hourly,
        Salaried,
        Manager
    }
}