﻿using System.Drawing;

namespace LabCorp.Model
{
    public class HourlyEmployee : Employee
    {
        public HourlyEmployee()
        {
            this.EmployeeType = EmployeeType.Hourly;
        }
        public override int MaxVacationDays
        {
            get
            {
                return 10;
            }
        }
    }
}
